package com.lista.gerador_senhas;

public class Main {
    public static void main(String[] args) {
        Gerador gerador = new Gerador();
        gerador.Gerar();
    }
}
