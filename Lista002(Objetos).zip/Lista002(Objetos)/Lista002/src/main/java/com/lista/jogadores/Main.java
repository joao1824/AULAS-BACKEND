package com.lista.jogadores;

public class Main {
    public static void main(String[] args) {
        JogadorAleatorio jogadorAleatorio = new JogadorAleatorio();
    }
}
