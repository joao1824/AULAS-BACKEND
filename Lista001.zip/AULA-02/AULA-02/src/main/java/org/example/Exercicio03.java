package org.example;

public class Exercicio03 {
    public static void main(String[] args){
        String produto = "Mouse";
        int codigo = 1234;
        double preco_unitario = 500.00;
        boolean promocao = true;

        System.out.println("Produto: " + produto);
        System.out.println("codigo: " + codigo);
        System.out.println("Preço: " + preco_unitario);
        System.out.println("Promoção: " + promocao);
    }
}
