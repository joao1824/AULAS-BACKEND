package org.example;

public class Exercicio02 {
    public static void main(String[] args){
        String nome = "Mario";
        String cargo = "Professor";
        Double salario = 5000.0;

        System.out.println("Nome: " + nome);
        System.out.println("Cargo: " + cargo);
        System.out.println("Salário: " + salario);
    }
}
