package org.example;

public class Exercicio01 {
    public static void main(String[] args) {
        String boas_vindas = "Bem-vindo ao Sistema de Geração de Jogadores!";
        System.out.println(boas_vindas);
    }
}